/****************************************************************************/
/*Desenvolvedor:    Anderson Madeira da Cruz                  1701570240    */
/*Instituição:      Universidade Federal do Pampa(UNIPAMPA)                 */
/*Obejtivo:         Biblioteca para shield de arduino desenvolvido para     */
/*                  facilitar o uso da Estação Meteorologica em sala de     */
/*                  aula com alunos do ensino medio                         */
/*Prof.Orientadores:Pedro Dornelis                                          */
/*                                                                          */
/****************************************************************************/
                                                                            //
#include <EstMet.h>                                                         //
                                                                            //
/***********************Defines pinos****************************************/
                                                                            //
#define DHT_PIN 4                                                           //                                                          
#define LM_PIN  A0                                                          //
#define ANE_PIN 3                                                           //
#define BIR_PIN A3                                                          //
                                                                            //
/***********************Defines sensor DHT***********************************/
                                                                            //
//#define DHTTYPE DHT11                                                     // DHT 11
#define DHTTYPE DHT22                                                       // DHT 22  (AM2302) -- Tipo de sensor que está sendo utilizado
//#define DHTTYPE DHT21                                                     // DHT 21 (AM2301)
DHT dht(DHT_PIN, DHTTYPE);                                                  // Declara a variavel do sensor DHT
                                                                            //
/****************************************************************************/
                                                                            //
EstMet::EstMet(int i){                                                      //Inicialização da biblioteca onde ela configura os pinos e variaveis
    pinMode(LM_PIN, INPUT);                                                 //
    pinMode(DHT_PIN, INPUT);                                                //
    pinMode(ANE_PIN, INPUT);                                                //
    pinMode(BIR_PIN, INPUT);                                                //
    _leit = 0;                                                              //
}                                                                           //
                                                                            //
/****************************************************************************/
                                                                            //
String EstMet::dir_vento(){                                                 //Nome da função:           Função direção do vento
    int dir;                                                                //Parâmetros de entrada:    Não possui
    dir = analogRead(BIR_PIN);                                              //Funcionamento:            Lê o sensor que indica a direção do vento
    if(dir > 655 && dir < 700)  return "N";                                 //Retorno:                  String que indica a direção do vento
    if(dir > 490 && dir < 535)  return "NE";                                // 
    if(dir > 380 && dir < 430)  return "E";                                 //
    if(dir > 318 && dir < 370)  return "SE";                                //
    if(dir > 266 && dir < 318)  return "S";                                 //
    if(dir > 246 && dir < 266)  return "SO";                                //
    if(dir > 215 && dir < 246)  return "O";                                 //
    if(dir > 180 && dir < 215)  return "NO";                                //
}                                                                           //
                                                                            //
/****************************************************************************/
                                                                            //
float EstMet::st(float temp, float vel_vento, float umi){                   //Nome da função:           Função sensação termica com parâmetro
    if(temp < 10 && vel_vento >= 5){                                        //Parâmetros de entrada:    Temperatura,
        st_baixa(temp, vel_vento);                                          //                          Velocidade do vento,
    }else if(temp > 26){                                                    //                          Umidade
        st_alto(temp, umi);                                                 //Funcionamento:            Através dos parâmetros de entrada ele
    }else{                                                                  //                          calcula a sensação termica
        return temp;                                                        //Retorno:                  Retorna um valor em float com o calculo
    }                                                                       //                          da sensação termica
}                                                                           //
                                                                            //
/****************************************************************************/
                                                                            //
float EstMet::st_auto(){                                                    //Nome da função:           Função sensação termica automatica
    float   temp = temp_lm35(),                                             //Parâmetros de entrada:    Não possui
            umi = dht.readHumidity();                                       //Funcionamento:            Lê os sensores de temperatura, umidade e
    if(temp < 10 && vel_vento >= 5){                                        //                          velocidade do vento e através das leituras
        st_baixa(temp, vel_vento);                                          //                          calcula a sensação termica
    }else if(temp > 26){                                                    //Retorno:                  Retorna um valor em float com o calculo
        st_alto(temp, umi);                                                 //                          da sensação termica
    }else{                                                                  //
        return temp;                                                        //
    }                                                                       //
}                                                                           //
                                                                            //
/****************************************************************************/
                                                                            //
float EstMet::st_baixa(float temp, float vel_vento){                        //Nome da função:           Função sensação termica baixa
    if(temp < 10 && vel_vento >= 5){                                        //Parâmetros de entrada:    Temperatura,
        return (13.12 + 0.6215 * temp - 11.37 * pow(vel_vento, 0.16) +      //                          Velocidade do vento
        0.3965 * temp * pow(vel_vento, 0.16));                              //Funcionamento:            Através dos parâmetros de entrada ele verifica
    }                                                                       //                          se estão de acordo com sensação termica 
    else    return temp;                                                    //                          baixa(velocidade do vento >= 5km/h, temperatua < 10),
}                                                                           //                          se sim calcula a sensação termica se não retorna a propria temperatura.
                                                                            //Retorno:                  Retorna um valor em float com o calculo de sensação termica
/****************************************************************************/
                                                                            //
float EstMet::st_alto(float temp, float umi){                               //Nome da função:           Função sensação termica alta
    if(temp > 26){                                                          //Parâmetros de entrada:    Temperatura,
        float tf = 32 + ((temp * 180) / 100);                               //                          Umidade
        float sf = -42.379 + 2.04901523 * tf + 10.14333127 * umi -          //Funcionamento:            Através dos parametros de entrada ele verifica
            0.22475541 * umi * tf - 0.00683783 * tf * tf - 0.05481717 *     //                          se estão de acordo com sensação termica alta    
            umi * umi + 0.00122874 * umi * tf * tf + 0.00085282 * tf *      //                          (temperatura > 26), se sim calcula a sensação termica
            umi * umi - 0.00000199 * umi * umi * tf * tf;                   //                          se não retorna a propria temperatura          
            return ((100 * (sf - 32)) / 180);                               //Retorno:                  Retorna um valor em float com o calculo de sensação termica
    }                                                                       //
    else    return temp;                                                    //
                                                                            //  
}                                                                           //
                                                                            //
/****************************************************************************/
                                                                            //
float EstMet::temp_lm35(){                                                  //Nome da função:           Função leitura de temperatura do sensor lm-35
    return((float(analogRead(LM_PIN))*5/(1023))/0.01);                      //Parâmetros de entrada:    Não possui
}                                                                           //Funcionamento:            Lê e calcula o valor da temperatura fornecida para o sensor
                                                                            //Retorno:                  Retorna um valor em float da temperatura
/****************************************************************************/
                                                                            //
void EstMet::anemometro(){                                                  //Nome da função:           Função anemometro
    _tmp_low += pulseIn(ANE_PIN, LOW, 2000000) / 1000;                      //Parâmetros de entrada:    Não possui
    if(_tmp_low != 0)    _leit++;                                           //Funcionamento:            Fica analisando o sensor de velocidade do vento
    else                _vel = 0;                                           //                          que está localizado na estação meteorologica, utiliza
    if(_leit == 3){                                                         //                          a função pulseIn para calcular o periodo de uma volta, 
        _tl_med = _tmp_low / 3;                                             //                          após fazer alguma leitura ele calcula a media de velocidade.
        _leit = 0;                                                          //Retorno:                  Não possui
        _tmp_low = 0;                                                       //
        _vel = (4 * 3.1415927 * 115) / _tl_med;                             //
    }//                                                                     //
}                                                                           //
                                                                            //
/****************************************************************************/
                                                                            //
float EstMet::velocidade(){                                                 //Nome da função:           Função velocidade
    return(_vel);                                                           //Parâmetros de entrada:    Não possui
}                                                                           //Funcionamento:            Lê o valor da velocidade que foi calculado na função anemometro
                                                                            //Retorno:                  Retorna um valor em float da velocidade
/****************************************************************************/
                                                                            //
float EstMet::humidade(){                                                   //Nome da função:           Função umidade
    return dht.readHumidity();                                              //Parâmetros de entrada:    Não possui
}                                                                           //Funcionamento:            Lê o valor de umidade em % fornecido pelo sensor DHT
                                                                            //Retorno:                  Retorna um valor em float da % de umidade
/****************************************************************************/