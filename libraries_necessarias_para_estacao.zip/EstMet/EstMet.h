/********************************************************************/
/*                                                                  */
/********************************************************************/
                                                                    //
#ifndef EstMet_h                                                    //
#define EstMet_h                                                    //
                                                                    //
    #include <Arduino.h>                                            //
    #include "DHT.h"                                                //
    #include "Adafruit_Sensor.h"                                    //
                                                                    //
    class EstMet{                                                   //
        public:                                                     //
            EstMet(int i);                                          //
            String dir_vento();                                     //
            float   st(float temp, float vel_vento, float umi);     //
            float   st_auto();                                      //
            float   st_baixa(float temp, float vel_vento);          //
            float   st_alto(float temp, float umi);                 //
            float   temp_lm35();                                    //
            void    anemometro();                                   //
            float   velocidade();                                   //
            float   humidade();                                     //
        private:                                                    //
            int     _leit;                                          //
            float   _vel;                                           //
            double   _tmp_low,_tl_med;                              //
    };                                                              //
#endif                                                              //
                                                                    //
/********************************************************************/